algoritmos = {
  'bl' :  "Búsqueda Local",
  'agg' : "Algoritmo Genético (Generacional)",
  'age' : "Algoritmo Genético (Estacionario)",
  'am' :  "Algoritmo Memético",
  'es' :  "Enfriamiento Simulado",
  'bmb' : "Búsqueda Multiarranque Básica",
  'ils' : "Búsqueda Local Reiterada"
}

descripcion = """Prácticas MH 2020/2021
======================

Alumno:  Miguel Ángel Fernández Gutiérrez
Curso:   2020/2021
Grupo:   MH3
Entrega: Práctica 3
"""

semilla_default = 1514280522468089

num_clusters_map = {'bupa': 16, 'glass': 7, 'zoo': 7}
