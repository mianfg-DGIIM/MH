from algoritmos.par_greedy import Greedy
from algoritmos.par_bl import BL
from algoritmos.par_ag import AGG, AGE
from algoritmos.par_am import AM
from algoritmos.par_es import ES
from algoritmos.par_bmb import BMB
from algoritmos.par_ils import ILS
